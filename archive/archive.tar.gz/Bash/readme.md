
# Resources

This sub folder is based on following course:

- Bash Shell Scripting
    - https://learning.oreilly.com/videos/bash-shell-scripting/9780137689064/


# Bash cheatsheet

- https://devhints.io/bash

- https://github.com/RehanSaeed/Bash-Cheat-Sheet

- https://algodaily.com/lessons/bash-commands-cheat-sheet1

- https://tldp.org/LDP/Bash-Beginners-Guide/html/